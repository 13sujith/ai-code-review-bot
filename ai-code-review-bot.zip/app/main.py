import os
import hmac
import hashlib
import logging

from fastapi import FastAPI, Request, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
from dotenv import load_dotenv

from app.github_client import (
    get_pr_diff,
    get_pr_details,
    post_pr_comment,
    add_pr_label,
)
from app.reviewer import run_review

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(name)s | %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI(title="AI Code Review Bot", version="1.0.0")

WEBHOOK_SECRET = os.environ.get("GITHUB_WEBHOOK_SECRET", "")


# ── Signature verification ────────────────────────────────────────────────────

def verify_signature(payload_bytes: bytes, signature_header: str | None) -> bool:
    """Verify GitHub's HMAC-SHA256 webhook signature."""
    if not WEBHOOK_SECRET:
        return True                    # skip verification in local dev
    if not signature_header:
        return False
    expected = "sha256=" + hmac.new(
        WEBHOOK_SECRET.encode(), payload_bytes, hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(expected, signature_header)


# ── Background review task ────────────────────────────────────────────────────

async def handle_review(repo: str, pr_number: int, commit_sha: str) -> None:
    """Fetch the diff, run the AI review, and post the comment."""
    try:
        logger.info("Starting review for %s #%d", repo, pr_number)

        # 1. Get PR details and diff
        details = await get_pr_details(repo, pr_number)
        diff    = await get_pr_diff(repo, pr_number)

        if not diff.strip():
            logger.info("Empty diff — skipping review.")
            return

        # 2. Run AI review
        review = await run_review(
            diff=diff,
            pr_title=details.get("title", ""),
            pr_description=details.get("body", "") or "",
        )

        # 3. Post comment + label
        await post_pr_comment(repo, pr_number, review)
        await add_pr_label(repo, pr_number, ["ai-reviewed"])

        logger.info("Review posted for %s #%d ✓", repo, pr_number)

    except Exception as exc:
        logger.error("Review failed for %s #%d: %s", repo, pr_number, exc, exc_info=True)
        try:
            await post_pr_comment(
                repo, pr_number,
                f"⚠️ **AI Code Review Bot** encountered an error:\n```\n{exc}\n```"
            )
        except Exception:
            pass


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/")
async def health():
    return {"status": "ok", "bot": "AI Code Review Bot"}


@app.post("/review")
async def webhook(request: Request, background_tasks: BackgroundTasks):
    """
    GitHub webhook endpoint.
    Triggered by pull_request events (opened / synchronize / reopened).
    """
    body = await request.body()

    # Verify webhook signature
    sig = request.headers.get("X-Hub-Signature-256")
    if not verify_signature(body, sig):
        raise HTTPException(status_code=401, detail="Invalid webhook signature")

    event = request.headers.get("X-GitHub-Event", "")
    if event != "pull_request":
        return JSONResponse({"skipped": f"event '{event}' not handled"})

    payload    = await request.json()
    action     = payload.get("action", "")
    pr         = payload.get("pull_request", {})
    repo       = payload["repository"]["full_name"]
    pr_number  = pr["number"]
    commit_sha = pr["head"]["sha"]

    if action not in ("opened", "synchronize", "reopened"):
        return JSONResponse({"skipped": f"action '{action}' not handled"})

    # Run review in background so GitHub doesn't time out waiting
    background_tasks.add_task(handle_review, repo, pr_number, commit_sha)

    return JSONResponse({"status": "review started", "pr": pr_number})
