def build_review_prompt(diff: str, pr_title: str = "", pr_description: str = "") -> str:
    context = ""
    if pr_title:
        context += f"PR Title: {pr_title}\n"
    if pr_description:
        context += f"PR Description: {pr_description}\n"

    return f"""You are a senior software engineer doing a thorough code review.

{context}

Review the following code diff and provide clear, constructive feedback.

Focus on:
1. **Bugs & Errors** — Logic errors, edge cases, null pointer issues
2. **Security** — SQL injection, XSS, hardcoded secrets, unsafe inputs
3. **Performance** — Unnecessary loops, missing indexes, memory leaks
4. **Code Quality** — Readability, naming, duplication, complexity
5. **Best Practices** — Design patterns, error handling, test coverage

Format your response as:

## 🔍 Code Review Summary

**Overall Assessment:** (Approved / Needs Changes / Critical Issues)

## 🐛 Issues Found

(List each issue with the line number if possible, severity: 🔴 Critical / 🟡 Warning / 🟢 Suggestion)

## ✅ What looks good

(Mention positive aspects)

## 💡 Suggestions

(Actionable improvements)

---
*Reviewed by AI Code Review Bot*

Here is the diff to review:

```diff
{diff}
```
"""


def build_summary_prompt(reviews: list[str]) -> str:
    combined = "\n\n".join(reviews)
    return f"""Summarize the following code review comments into a brief executive summary (3-5 sentences max):

{combined}
"""
