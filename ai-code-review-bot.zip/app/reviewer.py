import os
import logging
from anthropic import Anthropic
from app.prompt import build_review_prompt

logger = logging.getLogger(__name__)

# ── Client setup ──────────────────────────────────────────────────────────────
anthropic_client = Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))

# Max diff size to send to the AI (very large diffs get truncated)
MAX_DIFF_CHARS = 12_000


def _truncate_diff(diff: str) -> str:
    if len(diff) <= MAX_DIFF_CHARS:
        return diff
    logger.warning("Diff too large (%d chars), truncating to %d", len(diff), MAX_DIFF_CHARS)
    return (
        diff[:MAX_DIFF_CHARS]
        + "\n\n... [diff truncated — too large for a single review] ..."
    )


async def review_with_claude(
    diff: str,
    pr_title: str = "",
    pr_description: str = "",
) -> str:
    """Send the diff to Claude and return the review text."""
    diff = _truncate_diff(diff)
    prompt = build_review_prompt(diff, pr_title, pr_description)

    logger.info("Sending diff to Claude for review...")
    message = anthropic_client.messages.create(
        model="claude-opus-4-6",
        max_tokens=2048,
        messages=[{"role": "user", "content": prompt}],
    )
    review_text = message.content[0].text
    logger.info("Claude review received (%d chars)", len(review_text))
    return review_text


async def review_with_openai(
    diff: str,
    pr_title: str = "",
    pr_description: str = "",
) -> str:
    """Fallback: send the diff to GPT-4 and return the review text."""
    try:
        from openai import AsyncOpenAI  # optional dependency
    except ImportError:
        raise RuntimeError("openai package not installed. Run: pip install openai")

    diff = _truncate_diff(diff)
    prompt = build_review_prompt(diff, pr_title, pr_description)
    client = AsyncOpenAI(api_key=os.environ.get("OPENAI_API_KEY", ""))

    logger.info("Sending diff to GPT-4 for review...")
    response = await client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=2048,
    )
    review_text = response.choices[0].message.content
    logger.info("GPT-4 review received (%d chars)", len(review_text))
    return review_text


async def run_review(
    diff: str,
    pr_title: str = "",
    pr_description: str = "",
    provider: str = "claude",          # "claude" | "openai"
) -> str:
    """
    Main entry point. Choose AI provider via the REVIEW_PROVIDER env var
    or the `provider` argument. Falls back to Claude on error.
    """
    provider = os.environ.get("REVIEW_PROVIDER", provider).lower()

    try:
        if provider == "openai":
            return await review_with_openai(diff, pr_title, pr_description)
        return await review_with_claude(diff, pr_title, pr_description)
    except Exception as exc:
        logger.error("Primary provider '%s' failed: %s", provider, exc)
        if provider != "claude":
            logger.info("Falling back to Claude...")
            return await review_with_claude(diff, pr_title, pr_description)
        raise
