import os
import httpx
from typing import Optional

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
GITHUB_API   = "https://api.github.com"

HEADERS = {
    "Authorization": f"token {GITHUB_TOKEN}",
    "Accept":        "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
}


async def get_pr_diff(repo: str, pr_number: int) -> str:
    """Fetch the raw unified diff for a pull request."""
    url = f"{GITHUB_API}/repos/{repo}/pulls/{pr_number}"
    async with httpx.AsyncClient() as client:
        response = await client.get(
            url,
            headers={**HEADERS, "Accept": "application/vnd.github.v3.diff"},
            timeout=30,
        )
        response.raise_for_status()
        return response.text


async def get_pr_details(repo: str, pr_number: int) -> dict:
    """Fetch PR metadata: title, body, author, etc."""
    url = f"{GITHUB_API}/repos/{repo}/pulls/{pr_number}"
    async with httpx.AsyncClient() as client:
        response = await client.get(url, headers=HEADERS, timeout=15)
        response.raise_for_status()
        return response.json()


async def post_pr_comment(repo: str, pr_number: int, body: str) -> dict:
    """Post a comment on the PR (issue-level comment)."""
    url = f"{GITHUB_API}/repos/{repo}/issues/{pr_number}/comments"
    async with httpx.AsyncClient() as client:
        response = await client.post(
            url,
            headers=HEADERS,
            json={"body": body},
            timeout=15,
        )
        response.raise_for_status()
        return response.json()


async def post_review(
    repo: str,
    pr_number: int,
    commit_sha: str,
    body: str,
    event: str = "COMMENT",          # APPROVE | REQUEST_CHANGES | COMMENT
) -> dict:
    """Post a formal GitHub PR review (shows as a review, not just a comment)."""
    url = f"{GITHUB_API}/repos/{repo}/pulls/{pr_number}/reviews"
    async with httpx.AsyncClient() as client:
        response = await client.post(
            url,
            headers=HEADERS,
            json={"commit_id": commit_sha, "body": body, "event": event},
            timeout=15,
        )
        response.raise_for_status()
        return response.json()


async def add_pr_label(repo: str, pr_number: int, labels: list[str]) -> None:
    """Add labels to a PR (e.g. 'ai-reviewed')."""
    url = f"{GITHUB_API}/repos/{repo}/issues/{pr_number}/labels"
    async with httpx.AsyncClient() as client:
        await client.post(url, headers=HEADERS, json={"labels": labels}, timeout=10)
